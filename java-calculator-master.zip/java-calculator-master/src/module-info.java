/**
 * 
 */
/**
 * 
 */
module com.raghav.calculator {
	requires org.junit.jupiter.api;
}